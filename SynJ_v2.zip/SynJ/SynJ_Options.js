// SynJ_Options

// SynJ_Options is the fuction for selecting the options and parameters for SynJ algorithms
// Start developing 01-2020
// Alessandro Moro, FGA CNCR VU Amsterdam

importClass(Packages.ij.IJ);
importClass(Packages.ij.WindowManager);
importClass(Packages.ij.ImagePlus);
